import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {Pais} from '../../model/livro';
import {DestinoPage} from '../../pages/destino/destino';
/**
 * Created by leonardo_soares on 28/05/2018.
 * RA 816114026
 */
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public pais : Pais [];

  constructor(public navCtrl: NavController) {
    this.pais = [];
    var l1 = {nome:'Algeria', descricaoPais:'Região: África - capital: Algiers',codigo:'Código: DZA', capital:'Capital: Algiers', regiao:'Região: Africa',subRegiao:'Sub Região: Nothern Africa',demonimo:'Demonimo: Algerian',populacao:'População: 40400000',area:'Area: 2381741',gini:'Gini: 35.3',idiomas:'Idiomas: Arabic', moedas:'Moedas: Algerian dinar',dominios:'Dominios: .dz',fusos:'Fuso Horário: UTC+01:00', fronteiras:'Fronteiras: TUN, LBY, NER, ESH, MRT, MLI, MAR', latitude: 'Latitude: 28.0', longitude:'Longitude: 3.0'};
 var l2 = {nome:'angola', descricaoPais:'Região: África - capital: Luanda',codigo:'Código: AGO', capital:'Capital: Luanda', regiao:'Região: Africa',subRegiao:'Sub Região:Middle Africa',demonimo:'Demonimo: Angolan',populacao:'População: 25868000',area:'Area: 1246700',gini:'Gini: 58.6',idiomas:'Idiomas: Português', moedas:'Moedas: Angolan Kwanza',dominios:'Dominios: .ao',fusos:'Fuso Horário:UTC+01:00', fronteiras:'Fronteiras: COG, COD, ZMB, NAM', latitude: 'Latitude: 12.5', longitude:'Longitude: 18.5'};
 var l3 = {nome:'Benin', descricaoPais:'Região: África - capital: Porto-Novo',codigo:'Código: BEN', capital:'Capital: Porto-Novo', regiao:'Região: Africa',subRegiao:'Sub Região:Middle Africa',demonimo:'Demonimo: Beninese',populacao:'População: 10653654',area:'Area: 112622',gini:'Gini: 38.6',idiomas:'Idiomas: French', moedas:'Moedas: West African CFA franc',dominios:'Dominios: .bj',fusos:'Fuso Horário:UTC+01:00', fronteiras:'Fronteiras: BFA, NER, NGA, TGO', latitude: 'Latitude: 9.5', longitude:'Longitude: 2.25'};
 var l4 = {nome:'British', descricaoPais:'Região: África - capital: Diego Garcia',codigo:'Código: IOT', capital:'Capital: Diego Garcia', regiao:'Região: Africa',subRegiao:'Sub Região:Eastern Africa',demonimo:'Demonimo: Indian',populacao:'População: 3000',area:'Area: 60',gini:'Gini: 0.0',idiomas:'Idiomas: English', moedas:'Moedas: United States dollar',dominios:'Dominios: .io',fusos:'Fuso Horário:UTC+06:00', fronteiras:'Fronteiras: ', latitude: 'Latitude: 6.0', longitude:'Longitude: 71.5'};
 var l5 = {nome:'Botswana', descricaoPais:'Região: África - capital: Gabarone',codigo:'Código: BWA', capital:'Capital: Gaborone', regiao:'Região: Africa',subRegiao:'Sub Região:Southern Africa',demonimo:'Demonimo: Motswana',populacao:'População: 2141206',area:'Area: 582000',gini:'Gini: 61.0',idiomas:'Idiomas: English, Tswana', moedas:'Moedas: Botswana pula',dominios:'Dominios: .bw',fusos:'Fuso Horário:UTC+02:00', fronteiras:'Fronteiras: NAM, ZAF, ZMB, ZWE', latitude: 'Latitude: 22.0', longitude:'Longitude: 24.0'};
 this.pais = [l1, l2, l3, l4, l5]; 
  }
  irParaDestino(pais:Pais):void{
    this.navCtrl.push(DestinoPage, {paisSelecionado: pais});
    }
    
}
