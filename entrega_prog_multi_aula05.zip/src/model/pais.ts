/**
 * Created by leonardo_soares on 28/05/2018.
 * RA 816114026
 */

export interface Pais{
    nome: string;
    descricaoPais:string;
    codigo:string;
    capital:string;
    regiao:string;
    subRegiao:string;
    demonimo:string;
    populacao:string;
    area:string;
    gini:string;
    idiomas:string;
    moedas:string;
    dominios:string;
    fusos:string;
    fronteiras:string;
    latitude:string;
    longitude:string;
}