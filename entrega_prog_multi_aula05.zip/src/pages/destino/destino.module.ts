import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DestinoPage } from './destino';
/**
 * Created by leonardo_soares on 28/05/2018.
 * RA 816114026
 */
@NgModule({
  declarations: [
    DestinoPage,
  ],
  imports: [
    IonicPageModule.forChild(DestinoPage),
  ],
})
export class DestinoPageModule {}
